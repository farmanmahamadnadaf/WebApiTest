﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using System.Net.Http;
using System.Web.Mvc;
using WebApiTestApp;
using System.Web.Http.Description;
using System.Threading.Tasks;

namespace WebApiTestApp.Controllers
{
    public class CustomersController : ApiController
    {
        private WebApiDemoEntities db = new WebApiDemoEntities();


        [System.Web.Http.HttpGet]
        [System.Web.Http.Route("api/GetAllOrderByCutomer")]
        
        public IEnumerable<Order> GetAllOrderByCutomer(int id)
        {

            List<Order> order = db.Orders.Where(a => a.CustomerId == id).ToList();
           
            return order;
        }

        [System.Web.Http.HttpGet]
        [System.Web.Http.Route("api/GetAllItemByOrder")]
        [ResponseType(typeof(IEnumerable<Item>))]
        public IHttpActionResult GetAllItemByOrder(int id)
        {
            List<Item> itmList = db.Items.Where(a => a.OrderId == id).ToList();
            if (itmList == null)
            {
                return NotFound();
            }
            return Ok(itmList);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/AddCustomer")]
        [ResponseType(typeof(Customer))]
        public IHttpActionResult AddCustomer(Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Customers.Add(customer);
            db.SaveChanges();
            return Ok(customer);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/AddOrder")]
        [ResponseType(typeof(Order))]
        public IHttpActionResult AddOrder(Order order)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Orders.Add(order);
            db.SaveChanges();
            return Ok(order);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/AddItem")]
        //[ResponseType(typeof(Order))]
        [ResponseType(typeof(Item))]

        public IHttpActionResult AddItem(Item item)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Items.Add(item);
            db.SaveChanges();
            return Ok(item);
        }



        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


    }
}
